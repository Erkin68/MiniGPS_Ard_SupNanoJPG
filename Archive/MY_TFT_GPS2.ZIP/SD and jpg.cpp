#define LOAD_SD_LIBRARY
#define LOAD_SDFAT_LIBRARY


#include "D:\arduino-nightly\libraries\SD\src\utility\SD2Card.h"
#define sd_cs  4
Sd2Card card;

// this function determines the minimum of two numbers
#define minimum(a,b)     (((a) < (b)) ? (a) : (b))

#include <D:\Temp\Arduino\MY_TFT_GPS\Adafruit_ST7735.h>
extern Adafruit_ST7735 tft;

extern char njDecode(const void*, const int);
char jpgBuf[64];

void SD_Setup()
{
  // try to access the SD card. If that fails (e.g.
  // no card present), the setup process will stop.
  Serial.print(F("Initializing SD card..."));
  if(!card.init(SPI_HALF_SPEED, sd_cs)) { //if (!SD.begin(sd_cs)) {
    Serial.println(F("failed!"));
    while (1); // SD initialisation failed so wait here
  }
  Serial.println(F("OK!"));

  if(!card.readData(0,0,64,jpgBuf));
  
}





//====================================================================================
//   Main loop
//====================================================================================
 void JPG_loop() {

  // render the image onto the screen at coordinate 0,0
  char r = njDecode(jpgBuf, 3768);

  // wait a little bit before clearing the screen to random color and drawing again
  delay(4);

  // clear screen
  //tft.fillScreen(random(0xFFFF));  // Alternative: TFTscreen.background(255, 255, 255);
}
