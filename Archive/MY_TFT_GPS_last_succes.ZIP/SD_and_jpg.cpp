#include "SD2Card.h"
#define sd_cs  4
Sd2Card card;

// this function determines the minimum of two numbers
#define minimum(a,b)     (((a) < (b)) ? (a) : (b))

#include <D:\Temp\Arduino\MY_TFT_GPS\Adafruit_ST7735.h>

extern char njDecode(short);

#define BLOCKSZ 512
#define BUFSZ 132
#define HALFBUFSZ 66
unsigned char buf[BUFSZ];
unsigned short jpgsize=2723;//3662;
unsigned short OffsetInSDBlock = 0;
uint32_t SDBlockNum = 2561;//26820009;//total blocks:31260672
char SD_Inited;

void SD_Setup()
{
  SD_Inited = true;

  pinMode(SPI_MISO_PIN, INPUT);
  if(!card.init(sd_cs)) 
    SD_Inited = false;
  else {
  }
}

int SDread(unsigned char *pbuf,int cnt)
{ if(!SD_Inited)return 0;
  if(OffsetInSDBlock>=BLOCKSZ)
  { ++SDBlockNum;
    OffsetInSDBlock = BLOCKSZ-OffsetInSDBlock;
  }
  char s[64];
  sprintf(s," sdrd:%d %d ",(int)(pbuf-&buf[0]),cnt);Serial.println(s);
  int lend = OffsetInSDBlock+cnt;
  int tail = lend - BLOCKSZ;
  if(tail<=0)
  { if(card.readData(SDBlockNum,OffsetInSDBlock,cnt,pbuf))
    { OffsetInSDBlock += cnt;
      sprintf(s," sdrd1:%d ",cnt);Serial.println(s);
      for(int i=0; i<cnt; i++){sprintf(s," %x ",*(pbuf+i));Serial.println(s);}
      return cnt;
    }
    return 0;
  }
  
  int fst = BLOCKSZ - OffsetInSDBlock;
  card.readData(SDBlockNum++,OffsetInSDBlock,fst,pbuf);
  sprintf(s," sdrd2:%d ",fst);Serial.println(s);
  for(int i=0; i<fst; i++){sprintf(s," %x ",*(pbuf+i));Serial.println(s);}
  pbuf += fst;
  fst = cnt - fst;
  OffsetInSDBlock = 0;
  card.readData(SDBlockNum,OffsetInSDBlock,fst,pbuf);
  sprintf(s," sdrd3:%d ",fst);Serial.println(s);
  for(int i=0; i<cnt; i++){sprintf(s," %x ",*(pbuf+i));Serial.println(s);}
  OffsetInSDBlock = fst;
  return cnt;
}

//====================================================================================
//   Main loop
//====================================================================================
 void JPG_loop() {

  if(SD_Inited)
  { 
    if(card.readData(SDBlockNum,OffsetInSDBlock,BUFSZ,buf))
    { char s[16];
      sprintf(s," jpglp sdrd:%d ",BUFSZ);Serial.println(s);
      for(int i=0; i<132; i++){sprintf(s," %x ",buf[i]);Serial.println(s);}
      OffsetInSDBlock = BUFSZ;
      char r = njDecode(jpgsize);//to TFT ret NJ_OK if all right;
      //card.readEnd();      
    }
  }
}
