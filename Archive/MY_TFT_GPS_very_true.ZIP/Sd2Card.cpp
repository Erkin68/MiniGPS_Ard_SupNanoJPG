//#define USE_SPI_LIB agar tft hw spi ishlatsa, buni // qilib qo'y!!!!
#include <Arduino.h>
#include "Sd2Card.h"
//------------------------------------------------------------------------------
// functions for hardware SPI
/** Send a byte to the card */
static void spiSend(uint8_t b) {
  SPDR = b;
  while (!(SPSR & (1 << SPIF)))
    ;
}
/** Receive a byte from the card */
static  uint8_t spiRec(void) {
  spiSend(0XFF);
  return SPDR;
}

// send command and return error code.  Return zero for OK
uint8_t Sd2Card::cardCommand(uint8_t cmd, uint32_t arg, uint8_t res) {
  
  chipSelectLow();

  // wait up to 300 ms if busy
  //spiRec();//waitNotBusy(300);

  // send command
  spiSend(cmd | 0x40);

  // send argument
  for (int8_t s = 24; s >= 0; s -= 8) spiSend(arg >> s);

  // send CRC
  uint8_t crc = (cmd == CMD0 ? 0x95 : 0xff);//0XFF;
  //if (cmd == CMD0) crc = 0X95; // correct crc for CMD0 with arg 0
  //if (cmd == CMD8) crc = 0X87; // correct crc for CMD8 with arg 0X1AA
  //if (cmd == CMD17) crc = 0X87; 
  spiSend(crc);

  // wait for response
  //while((status_ = spiRec()) != res);
  //for (uint8_t i = 0; ((status_ = spiRec()) & 0X80) && i != 0XFF; i++)
  //  ;
  for(uint8_t i = 0; i < 10; ++i)
  { status_ = spiRec();
    if(status_ == res)
      break;
  }
  return status_;
}

void Sd2Card::chipSelectHigh(void) {
  digitalWrite(chipSelectPin_, HIGH);
}

void Sd2Card::chipSelectLow(void) {
  digitalWrite(chipSelectPin_, LOW);
}

uint8_t Sd2Card::init(uint8_t chipSelectPin) {
  errorCode_ = type_ = 0;
  chipSelectPin_ = chipSelectPin;
  // 16-bit init start time allows over a minute
  uint16_t t0 = (uint16_t)millis();
  uint32_t arg;

  // set pin modes
  pinMode(chipSelectPin_, OUTPUT);
  digitalWrite(chipSelectPin_, HIGH);
  pinMode(SPI_MISO_PIN, INPUT);
  pinMode(SPI_MOSI_PIN, OUTPUT);
  pinMode(SPI_SCK_PIN, OUTPUT);

  // SS must be in output mode even it is not chip select
  pinMode(SS_PIN, OUTPUT);
  digitalWrite(SS_PIN, HIGH); // disable any SPI device using hardware SS pin

  SPCR = (0 << SPIE) | // SPI Interrupt Enable  Enable SPI, Master, clock rate f_osc/128   //SPCR = (1 << SPE) | (1 << MSTR) | (1 << SPR1) | (1 << SPR0);
  (1 << SPE) | // SPI Enable
  (0 << DORD) | // Data Order: MSB first
  (1 << MSTR) | // Master mode
  (0 << CPOL) | // Clock Polarity: SCK low when idle
  (0 << CPHA);// |  Clock Phase: sample on rising SCK edge 
  //(1 << SPR1) | // Clock Frequency: f_OSC / 128  hech kay namon;
  //(1 << SPR0);
  SPCR &= ~((1 << SPR1) | (1 << SPR0));
  SPSR &= ~(1 << SPI2X); // No doubled clock frequency 

  for (uint8_t i = 0; i < 10; i++) spiSend(0XFF);
            Serial.println("in 1");
  chipSelectLow();

  // command to go idle in SPI mode
  while ((status_ = cardCommand(CMD0, 0, R1_IDLE_STATE))!=R1_IDLE_STATE) {
    if (((uint16_t)(millis() - t0)) > SD_INIT_TIMEOUT) {
      error(SD_CARD_ERROR_CMD0);Serial.println("err tmu");
      goto fail;
    }
  }         Serial.println("in 2");
  
  delay(300);
  
  // check SD version
  if (cardCommand(CMD8, 0x1AA, R1_ILLEGAL_COMMAND)) {
    type(SD_CARD_TYPE_SD1);Serial.println("tp sd1");
  } else {
    // only need last byte of r7 response
    for (uint8_t i = 0; i < 4; i++) status_ = spiRec();
    if (status_ != 0XAA) {
      error(SD_CARD_ERROR_CMD8);      Serial.println("err 1");
      goto fail;
    }
    type(SD_CARD_TYPE_SD2);Serial.println("tp sd2");
  }
  // initialize card and send host supports SDHC if SD2
  arg = type() == SD_CARD_TYPE_SD2 ? 0X40000000 : 0;

  if (type() == SD_CARD_TYPE_SD1) {
    while(cardCommand(CMD0+1, 0, 0));
  }
  else if (type() == SD_CARD_TYPE_SD2) {// if SD2 read OCR register to check for SDHC card
   while ((status_ = cardAcmd(ACMD41, arg)) != R1_READY_STATE) {
      // check for timeout
      if (((uint16_t)(millis() - t0)) > SD_INIT_TIMEOUT) {
          error(SD_CARD_ERROR_ACMD41);Serial.println("tp er acm");
          goto fail;
        }
      }
    /*if (cardCommand(CMD58, 0)) {
      error(SD_CARD_ERROR_CMD58);//Serial.println("err cm58");
      goto fail;
    }
    if ((spiRec() & 0XC0) == 0XC0) type(SD_CARD_TYPE_SDHC);
    // discard rest of ocr - contains allowed voltage range
    for (uint8_t i = 0; i < 3; i++) spiRec();*/
  }
    
  chipSelectHigh();//Serial.println("tp in fn");

  return true;

 fail:
  chipSelectHigh();
  return false;
}

uint8_t Sd2Card::readData(uint32_t block, uint16_t offset, uint16_t count, uint8_t* dst) {
  int i = offset;
  if (count == 0) return true;
  if ((count + offset) > 512) {
    goto fail;
  }
  Serial.println("rd 1");
  // use address if not SDHC card
  if (type()!= SD_CARD_TYPE_SDHC) block <<= 9;
  //unsigned char ch = cardCommand(CMD17, block);
  if (cardCommand(CMD17, block, 0)) {
    error(SD_CARD_ERROR_CMD17);//char s[16];sprintf(s,"cmd17: %x \n",ch);Serial.println(s);//"rd err1");
    goto fail;
  }

  while(spiRec()!=0xfe);
  
  Serial.println("rd 2");
  // skip data before offset
  for (; i; i--) {
    spiRec();
  }
  i=0;
  // transfer data
  for (; i<count; i++) {
    dst[i] = spiRec();
  }
  i=512-offset-count+2;//+2 - CRC
  for (; i; i--) {
    spiRec();
  }

  return true;

 fail:
  chipSelectHigh();
  return false;
}

uint8_t Sd2Card::waitNotBusy(uint16_t timeoutMillis) {
  uint16_t t0 = millis();
  do {
    if (spiRec() == 0XFF) return true;
  }
  while (((uint16_t)millis() - t0) < timeoutMillis);
  return false;
}
