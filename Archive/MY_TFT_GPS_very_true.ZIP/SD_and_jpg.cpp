#include "SD2Card.h"
#define sd_cs  4
Sd2Card card;

// this function determines the minimum of two numbers
#define minimum(a,b)     (((a) < (b)) ? (a) : (b))

//#include <D:\Temp\Arduino\MY_TFT_GPS\Adafruit_ST7735.h>

extern char njDecode(short);

#define BLOCKSZ 512
#define BUFSZ 132
#define HALFBUFSZ 66
unsigned char buf[BUFSZ];
short jpgsize=2723;//3662;
short OffsetInSDBlock = 0;
long SDBlockNum = 2561;//26820009;//total blocks:31260672
char SD_Inited;

void SD_Setup()
{
  // try to access the SD card. If that fails (e.g.
  // no card present), the setup process will stop.
  SD_Inited = true;

  pinMode(SPI_MISO_PIN, INPUT);
  Serial.print(F("Initializing SD card..."));
  if(!card.init(sd_cs)) {
    Serial.println(F("...failed!"));
    SD_Inited = false;
  }
  else {
    //uint32_t sz = card.cardSize();char s[32];sprintf(s, "SD size: %d", sz);Serial.println(s);
    Serial.println("sd ind ok,go read");
  }
}

int SDread(unsigned char *pbuf,int cnt)
{ //Serial.println("SDread...st.1");
  if(!SD_Inited)return 0;
  //Serial.println("SDread...st.2");
  if(OffsetInSDBlock>=BLOCKSZ)
  { ++SDBlockNum;
    OffsetInSDBlock = BLOCKSZ-OffsetInSDBlock;
  }
  
  //Serial.println("SDread...st.3");
  int lend = OffsetInSDBlock+cnt;
  int tail = lend - BLOCKSZ;
  if(tail<=0)
  { if(card.readData(SDBlockNum,OffsetInSDBlock,cnt,pbuf))
    { //Serial.println("SDread...st.4");
      OffsetInSDBlock += cnt;
      return cnt;
    }
    //Serial.println("SDread...st.5");
    return 0;
  }
  
  //Serial.println("SDread...st.6");
  int fst = BLOCKSZ - OffsetInSDBlock;
  card.readData(SDBlockNum++,OffsetInSDBlock,fst,pbuf);
  pbuf += fst;
  fst = cnt - fst;
  OffsetInSDBlock = 0;
  //Serial.println("SDread...st.7");
  card.readData(SDBlockNum,OffsetInSDBlock,fst,pbuf);
  OffsetInSDBlock = fst;
  return cnt;
}

//====================================================================================
//   Main loop
//====================================================================================
 void JPG_loop() {

  if(SD_Inited)
  { 
    Serial.println("JPG_LOOP::SD_Inited.");
 
    if(card.readData(SDBlockNum,OffsetInSDBlock,BUFSZ,buf))
    { 
      char s[64];for(int i=0; i<16; i++){
      sprintf(s,"%0x %0x %0x %0x %0x %0x %0x %0x\n", buf[i*8],buf[i*8+1],buf[i*8+2],buf[i*8+3],buf[i*8+4],buf[i*8+5],buf[i*8+6],buf[i*8+7]);
      Serial.println(s);}
      
      OffsetInSDBlock = BUFSZ;
      char r = njDecode(jpgsize);//to TFT
      //Serial.println(F("Decoding jpg finished successfully..."));
    }
  }

  // clear screen
  //tft.fillScreen(random(0xFFFF));  // Alternative: TFTscreen.background(255, 255, 255);
}
