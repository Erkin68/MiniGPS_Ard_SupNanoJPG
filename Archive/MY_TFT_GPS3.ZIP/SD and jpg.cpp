#define LOAD_SD_LIBRARY
#define LOAD_SDFAT_LIBRARY


#include "D:\arduino-nightly\libraries\SD\src\utility\SD2Card.h"
#define sd_cs  4
Sd2Card card;

// this function determines the minimum of two numbers
#define minimum(a,b)     (((a) < (b)) ? (a) : (b))

#include <D:\Temp\Arduino\MY_TFT_GPS\Adafruit_ST7735.h>
extern Adafruit_ST7735 tft;

extern char njDecode(short);

#define BLOCKSZ 512
#define BUFSZ 132
#define HALFBUFSZ 66
unsigned char buf[BUFSZ];
short jpgsize=3662;
short OffsetInSDBlock = 0;
int SDBlockNum = 0;

void SD_Setup()
{
  // try to access the SD card. If that fails (e.g.
  // no card present), the setup process will stop.
  Serial.print(F("Initializing SD card..."));
  if(!card.init(SPI_HALF_SPEED, sd_cs)) { //if (!SD.begin(sd_cs)) {
    Serial.println(F("failed!"));
    while (1); // SD initialisation failed so wait here
  }
  Serial.println(F("OK!"));

  if(card.readData(SDBlockNum,OffsetInSDBlock,BUFSZ,buf))
  { OffsetInSDBlock = BUFSZ;
    char r = njDecode(jpgsize);
  }
}

int SDread(unsigned char *pbuf,int cnt)
{
  if(OffsetInSDBlock+cnt<=BLOCKSZ)
  { if(card.readData(SDBlockNum,OffsetInSDBlock,cnt,pbuf))
    { OffsetInSDBlock += cnt;
      return cnt;
    }
    return 0;
  }
  int fst = BLOCKSZ - OffsetInSDBlock;
  if(fst>0)
    card.readData(SDBlockNum,OffsetInSDBlock,fst,pbuf);
  ++SDBlockNum;
  //OffsetInSDBlock = 0;
  fst = cnt - fst;
  if(fst>0)
  { card.readData(SDBlockNum,OffsetInSDBlock,fst,pbuf);
    OffsetInSDBlock = fst;
  }
  return cnt;
}

//====================================================================================
//   Main loop
//====================================================================================
 void JPG_loop() {

  // render the image onto the screen at coordinate 0,0
  //char r = njDecode(jpgBuf, 3768);

  // wait a little bit before clearing the screen to random color and drawing again
  delay(4);

  // clear screen
  //tft.fillScreen(random(0xFFFF));  // Alternative: TFTscreen.background(255, 255, 255);
}
