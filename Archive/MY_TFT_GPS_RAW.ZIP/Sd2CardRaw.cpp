#include <Arduino.h>
#include "Sd2CardRaw.h"

#define BLOCK_SIZE 512

#define pinClk 13
#define pinDataOut 11
#define pinDataIn 12
#define pinSdCs 4//10

#define select_card() digitalWrite(pinSdCs,LOW)
#define unselect_card() digitalWrite(pinSdCs,HIGH)


uint8_t sd_raw_rec_byte()
{
  Serial.println("rawrecbt 1.");
#ifndef SOFTWARE_SPI
  /* send dummy data for receiving some */
  SPDR = 0xff;
  while(!(SPSR & (1 << SPIF)));
  SPSR &= ~(1 << SPIF);
  Serial.println("rawrecbt 2.");
  return SPDR;
#else
  unsigned char res = 0;
  int i;
  for (i=0; i < 8; i ++){
  res = res << 1;
  res |= digitalRead(pinDataIn) & 0x01;
  digitalWrite(pinClk,HIGH);
  digitalWrite(pinClk,LOW);
  }
  return res;
#endif
}

void sd_raw_send_byte(uint8_t b)
{
#ifndef SOFTWARE_SPI
  SPDR = b;
  /* wait for byte to be shifted out */
  while(!(SPSR & (1 << SPIF)));
  //SPSR &= ~(1 << SPIF);
#else
  int i = 0;
  digitalWrite(pinClk,LOW);
  for (i=0x80; i > 0; i=i >> 1){
  digitalWrite(pinDataOut, ((b & i) == 0)?LOW:HIGH);
  digitalWrite(pinClk,HIGH);
  digitalWrite(pinClk,LOW);
  };
#endif
}

uint8_t sd_raw_send_command_r1(uint8_t command, uint32_t arg)
{
  uint8_t response;
  /* wait some clock cycles */
  sd_raw_rec_byte();
  /* send command via SPI */
  sd_raw_send_byte(0x40 | command);
  sd_raw_send_byte((arg >> 24) & 0xff);
  sd_raw_send_byte((arg >> 16) & 0xff);
  sd_raw_send_byte((arg >> 8) & 0xff);
  sd_raw_send_byte((arg >> 0) & 0xff);
  sd_raw_send_byte(command == CMD_GO_IDLE_STATE ? 0x95 : 0xff);
  /* receive response */
  for(uint8_t i = 0; i < 10; ++i)
  {
    response = sd_raw_rec_byte();
    if(response != 0xff)
    break;
  }
  return response;
}

uint8_t sd_raw_init()
{
  pinMode(pinSdCs, OUTPUT);
#ifndef SD_RAW_SOFTSPI
  /* enable outputs for MOSI, SCK, SS, input for MISO */
  //configure_pin_mosi();
  //configure_pin_sck();
  //configure_pin_ss();
  //configure_pin_miso();
  unselect_card();
  /* initialize SPI with lowest frequency; max. 400kHz during identification mode of card */
  SPCR = (0 << SPIE) | /* SPI Interrupt Enable */
  (1 << SPE) | /* SPI Enable */
  (0 << DORD) | /* Data Order: MSB first */
  (1 << MSTR) | /* Master mode */
  (0 << CPOL) | /* Clock Polarity: SCK low when idle */
  (0 << CPHA) | /* Clock Phase: sample on rising SCK edge */
  (1 << SPR1) | /* Clock Frequency: f_OSC / 128 */
  (1 << SPR0);
  SPSR &= ~(1 << SPI2X); /* No doubled clock frequency */
#else
  //pinMode(pinClk,OUTPUT);
  //pinMode(pinDataOut,OUTPUT);
  //pinMode(pinDataIn,INPUT);
#endif
  /* initialization procedure */
  /* card needs 74 cycles minimum to start up */
  Serial.println("init st1.");
  for(uint8_t i = 0; i < 10; ++i)
  {
    /* wait 8 clock cycles */
    sd_raw_rec_byte();
  }
  /* address card */
  select_card();
  Serial.println("init st2.");
  /* reset card */
  uint8_t response;
  for(uint16_t i = 0; ; ++i)
  {
    response = sd_raw_send_command_r1(CMD_GO_IDLE_STATE, 0);
    if(response == (1 << R1_IDLE_STATE))
    break;
    if(i == 0x1ff)
    {
      unselect_card();
      Serial.println("init error");
      return 0;
    }
  }
  Serial.println("init st3.");
  /* wait for card to get ready */
  for(uint16_t i = 0; ; ++i)
  {
    response = sd_raw_send_command_r1(CMD_SEND_OP_COND, 0);
    if(!(response & (1 << R1_IDLE_STATE)))
    break;
    if(i == 0x7fff)
    {
      unselect_card();
      return 0;
    }
  }
  Serial.println("init st4.");
  /* set block size to 512 bytes */
  if(sd_raw_send_command_r1(CMD_SET_BLOCKLEN, BLOCK_SIZE))
  {
    unselect_card();
    Serial.println("block size error");
    return 0;
  }
  /* deaddress card */
  unselect_card();
  Serial.println("init st5.");
  #ifndef SD_RAW_SOFTSPI
  // it seems not to work on highest spi frequency... a delay somewhere could help....
  /* switch to highest SPI frequency possible */
  //SPCR &= ~((1 << SPR1) | (1 << SPR0)); /* Clock Frequency: f_OSC / 4 */
  //SPSR |= (1 << SPI2X); /* Doubled Clock Frequency: f_OSC / 2 */
  #endif
  return 1;
}

uint8_t sd_raw_begin_read_blocks_until_no_stop(uint32_t block, uint8_t* buffer, uint8_t startBytes)
{
  select_card();
  if(sd_raw_send_command_r1(CMD_READ_SINGLE_BLOCK, BLOCK_SIZE * block ))
  {
    unselect_card();
    Serial.println("read command error");
    return 0;
  }
  /* wait for data block (start byte 0xfe) */
  while(sd_raw_rec_byte() != 0xfe);
  /* read byte block */
  for(uint16_t i = 0; i < BLOCK_SIZE; ++i)
  { *buffer = sd_raw_rec_byte();
    char s[8];sprintf(s,"%02x ",*buffer);Serial.println(s);
    if(0==i%32)Serial.println("\n");
    //++buffer;
  }
  /* read crc16 */
  sd_raw_rec_byte();
  sd_raw_rec_byte();
  /* deaddress card */
  unselect_card();
  /* let card some time to finish */
  sd_raw_rec_byte();
}
